const config = {
  clientId: "JIHdbViGLqi4Qvi2MVhT7Zkl80U5EWzB",
  domain: "dev-6oulj204w6qwe4dk.us.auth0.com"
};

export default config;